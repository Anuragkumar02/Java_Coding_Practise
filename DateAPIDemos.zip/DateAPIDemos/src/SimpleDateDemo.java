import java.util.Date;

public class SimpleDateDemo {

	public static void main(String[] args) {
		Date today = new Date();
		System.out.println(today);
		
		Date afterDate = new Date(118, 9, 8);
		System.out.println(afterDate);
		
		if(afterDate.after(today)){
			System.out.println("Yes! It is after afterDate");
		}else{
			System.out.println("No! It is not after afterDate");
		}
		
		Date beforeDate = new Date(118, 0, 3);
		System.out.println(beforeDate);
		
		if(beforeDate.before(today)){
			System.out.println("Yes! It is before today");
		}else{
			System.out.println("No! It is not before today");
		}
		
		int result = today.compareTo(afterDate);
		
		if(result > 0){
			System.out.println("Today is greater");
		}else if(result < 0){
			System.out.println("Today is smaller");
		}else{
			System.out.println("Both are equal.");
		}
		
		long timeTillNow = today.getTime();
		System.out.print("No. of milliseconds from 1 January 1970 12:00 morning ");
		System.out.println(timeTillNow);
		
		Date tomorrow = new Date();
		tomorrow.setTime(today.getTime()+3600*1000*24);
		System.out.println("Tomorrow is: " + tomorrow);
	}
}