import java.util.Date;

public class DateDemo {
	public static void main(String[] args) {
		Date today = new Date();//Today's date.
		//Count no. of miliseconds passed from 1 January 1970 to till this point.
		System.out.println(today);
		
		Date when = new Date(118, 0, 10);//10 January 2018
		//1900 is already assumed.
		
		if(when.before(today)){
			System.out.println("when is before today");
		}
		
		when = new Date(119, 10, 20);//20 November 2018
		
		if(when.after(today)){
			System.out.println("when is after today");
		}
		
		int dd = today.getDate();
		int month = today.getMonth();
		int year = today.getYear();
		
		month++;
		year += 1900;
		
		System.out.println(dd+"/"+month+"/"+year);
		
		long timeTillNow = today.getTime();
		//No. of milliseconds from 1st January 1970,00:00:00 am
		
		System.out.println(timeTillNow);
		
		today.setDate(25);
		System.out.println(today);
		
		today.setTime(today.getTime()+(3600L*1000*24));
		System.out.println(today);
	}
}