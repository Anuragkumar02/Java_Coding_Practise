import java.util.Calendar;

public class CalendarDemo {
	public static void main(String[] args) {
		Calendar calendar = Calendar.getInstance();
		
		System.out.print(calendar.get(Calendar.DATE));
		System.out.print("/"+(calendar.get(Calendar.MONTH)+1));
		System.out.println("/"+calendar.get(Calendar.YEAR));
		
		calendar.set(2018, Calendar.JANUARY, 18, 6, 23, 56);
		
		System.out.print(calendar.get(Calendar.DATE));
		System.out.print("/"+calendar.get(Calendar.MONTH)+1);
		System.out.println("/"+calendar.get(Calendar.YEAR));
		
		calendar.set(Calendar.MONTH, Calendar.FEBRUARY);
		
		System.out.print(calendar.get(Calendar.DATE));
		System.out.print("/"+(calendar.get(Calendar.MONTH)+1));
		System.out.println("/"+calendar.get(Calendar.YEAR));
		
		/*SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				
		System.out.println(sdf.format(calendar.getTime()));*/
	}
}