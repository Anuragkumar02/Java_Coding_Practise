import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public class DateFormatDemo {
	public static void main(String[] args) {
		Date today = new Date();
		System.out.println(today);
		
		today = new Date(118, 2, 10);//10th March 2018.
		/*today.setDate(10);
		today.setMonth(2);
		today.setYear(118);*/
		
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, Locale.UK);
		System.out.println(df.format(today));
		
		df = DateFormat.getDateInstance(DateFormat.MEDIUM, Locale.UK);
		System.out.println(df.format(today));
		
		df = DateFormat.getDateInstance(DateFormat.DEFAULT, Locale.UK);
		System.out.println(df.format(today));
		
		df = DateFormat.getDateInstance(DateFormat.LONG, Locale.UK);
		System.out.println(df.format(today));
		
		df = DateFormat.getDateInstance(DateFormat.FULL, Locale.UK);
		System.out.println(df.format(today));
		
		System.out.println("==================================================");
		
		df = DateFormat.getDateInstance(DateFormat.SHORT, Locale.US);
		System.out.println(df.format(today));
		
		df = DateFormat.getDateInstance(DateFormat.MEDIUM, Locale.US);
		System.out.println(df.format(today));
		
		df = DateFormat.getDateInstance(DateFormat.DEFAULT, Locale.US);
		System.out.println(df.format(today));
		
		df = DateFormat.getDateInstance(DateFormat.LONG, Locale.US);
		System.out.println(df.format(today));
		
		df = DateFormat.getDateInstance(DateFormat.FULL, Locale.US);
		System.out.println(df.format(today));
	}
}