import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class SimpleDateFormatDemo {
	public static void main(String[] args) throws ParseException{
		String input = null;
		Date today = new Date();
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.println(today);
		
		SimpleDateFormat sdf = new SimpleDateFormat("EEEE, dd MMMM, yyyy");
		System.out.println(sdf.format(today));
		
		sdf = new SimpleDateFormat("EEEE, dd MMMM, yyyy z a");
		System.out.println(sdf.format(today));
		
		sdf = new SimpleDateFormat("EEEE, dd MMMM, yyyy G");
		System.out.println(sdf.format(today));
		
		sdf = new SimpleDateFormat("dd/MM/yyyy");
		sdf.setLenient(true);
		
		System.out.print("Enter a date: ");
		input = scInput.nextLine();
		
		today = sdf.parse(input);
		System.out.println(today);
		
		scInput.close();
	}
}