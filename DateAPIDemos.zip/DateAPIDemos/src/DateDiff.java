import java.util.Date;

public class DateDiff {

	public static void main(String[] args) {
		Date today = new Date();
		System.out.println(today);
		
		Date when = new Date(118, 0, 10);//10 January 2018
		
		long difference = today.compareTo(when);
		
		if(difference > 0){
			System.out.println("Today is greater.");
		}else if(difference < 0){
			System.out.println("Today is smaller.");
		}else{
			System.out.println("Both are equal.");
		}
	}
}