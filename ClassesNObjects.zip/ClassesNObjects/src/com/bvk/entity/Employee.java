package com.bvk.entity;

public class Employee {
	
	private static int eid = 10;
	private int empid = ++eid;
	private String name;
	private float salary;
	
	public Employee(){
		
	}
	
	public Employee(String name, float salary){
		this.name = name;
		this.salary = salary;
	}
	
	public int getEmpid() {
		return empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getSalary(){
		return salary;
	}
	
	public void setSalary(float salary){
		this.salary = salary;
	}

	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", salary=" + salary + "]";
	}
	
	public static void printCount(){
		System.out.println("Last Employee ID: " + eid);
	}
	/*public String toString(){
		String text = "Employee ID: " + empid + "\n" +
					  "Employee Name: " + name + "\n" +
				      "Employee Salary: " + salary + "\n" +
					  "===========================================================\n";
		return text;
	}*/
}