package com.bvk.client;
import java.util.Scanner;

import com.bvk.entity.Employee;

public class ClientEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee empFirst = null;
		Employee empSecond = null;
		String name = null;
		float salary = 0.0f;
		
		Scanner scInput = new Scanner(System.in);
		
		Employee.printCount();
		
		System.out.print("Enter employee name: ");
		name = scInput.nextLine();
		
		System.out.print("Enter employee salary: ");
		salary = scInput.nextFloat();
				 scInput.nextLine();
		empFirst = new Employee(name, salary);
		
		System.out.print("Enter employee name: ");
		name = scInput.nextLine();
		
		System.out.print("Enter employee salary: ");
		salary = scInput.nextFloat();
				 scInput.nextLine();
		empSecond = new Employee(name, salary);
		
		System.out.println(empFirst);
		System.out.println(empSecond);
		scInput.close();
		
		Employee.printCount();
	}
}