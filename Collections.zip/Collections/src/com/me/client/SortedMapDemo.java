package com.me.client;

import java.util.Scanner;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import com.me.entity.Employee;

public class SortedMapDemo {

	public static void main(String[] args) {
		SortedMap<Integer, Employee>empRecords = new TreeMap<>();
		
		Scanner scInput = new Scanner(System.in);
		
		empRecords.put(2, new Employee(2, "abc", 90000));
		empRecords.put(1, new Employee(1, "xyz", 90000));
		empRecords.put(3, new Employee(3, "xyz", 90000));
		empRecords.put(5, new Employee(5, "xyz", 90000));
		empRecords.put(18, new Employee(18, "xyz", 90000));
		
		SortedMap<Integer, Employee>sortedMap = empRecords.subMap(1, 5);
		
		Set<Integer>empids = sortedMap.keySet();
		
		for (Integer eid : empids) {
			System.out.println(sortedMap.get(eid));
		}
		scInput.close();
	}
}