package com.me.client;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import com.me.entity.AscEmpid;
import com.me.entity.DscEmpid;
import com.me.entity.Employee;

public class SetDemo {

	public static void main(String[] args) {
		Set<Employee>employees = new TreeSet<Employee>();
		int choice = -1;
		
		Scanner scInput = new Scanner(System.in);
		
		Employee employee = new Employee(1,"xyz",100000);
		Employee employee1 = new Employee(2,"abc",100000);
		Employee employee2 = new Employee(1,"xyz",100000);
		Employee employee3 = new Employee(3,"abc",90000);
		
		employees.add(employee);
		employees.add(employee1);
		employees.add(employee2);
		employees.add(employee3);
		
		System.out.println("Following are the records:");
		for(Employee empl : employees){
			System.out.println(empl);
		}
		
		while(choice != 0){
			System.out.println("Following is the choice:");
			System.out.println("1. Ascending order of Employee ID");
			System.out.println("2. Descending order of Employee ID");
			System.out.println("0. Exit");
			
			choice = Integer.parseInt(scInput.nextLine());
			
			switch(choice){
			case 1:
				employees = new TreeSet<Employee>(new AscEmpid());
				employees.add(employee);
				employees.add(employee1);
				employees.add(employee2);
				employees.add(employee3);
				break;
			case 2:
				employees = new TreeSet<Employee>(new DscEmpid());
				employees.add(employee);
				employees.add(employee1);
				employees.add(employee2);
				employees.add(employee3);
				break;
			case 0:
				System.out.println("Exiting...");
				System.exit(0);
			}
			
			System.out.println("Following are the records:");
			for(Employee empl : employees){
				System.out.println(empl);
			}
		}
		scInput.close();
	}
}