package com.me.client;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrDemo1 {
	public static void main(String[] args) {
		ArrayList<Double> temperatures = new ArrayList<Double>();
		double temperature = 0.0;
		double value = 0.0;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.println("Enter a number. -999 to stop:");
		temperature = scInput.nextDouble();
		
		while(temperature != -999){	
			temperatures.add(temperature);
			temperature = scInput.nextDouble();
		}
		
		System.out.println("Which temperature value you want to check as existing?");
		value = scInput.nextDouble();
		
		if(temperatures.contains(value)){
			System.out.println("The temperature exists in List");
		}else{
			System.out.println("Such temperature does not exist!");
		}
		scInput.close();
	}
}