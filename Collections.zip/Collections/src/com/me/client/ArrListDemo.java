package com.me.client;

import java.util.ArrayList;

public class ArrListDemo {

	public static void main(String[] args) {
		ArrayList<Double> temperatures = new ArrayList<>();
		
		temperatures.add(44.67);
		temperatures.add(78D);
		temperatures.add(67.54);
		temperatures.add(44.67);
		
		System.out.println(temperatures);
		
		temperatures.add(1, 33.43);
		
		System.out.println(temperatures);
	}
}