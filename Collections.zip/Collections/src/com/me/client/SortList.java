package com.me.client;

import java.util.ArrayList;
import java.util.Collections;

public class SortList {

	public static void main(String[] args) {
		ArrayList<Double>temperatures = new ArrayList<Double>();
		
		temperatures.add(76.56);
		temperatures.add(10.98);
		temperatures.add(78.67);
		temperatures.add(55.65);
		temperatures.add(27D);
		
		System.out.println("Printing before sorting:");
		System.out.println(temperatures);
		
		Collections.sort(temperatures);
		
		System.out.println("Printing after sorting in ascending order:");
		System.out.println(temperatures);
		
		Collections.sort(temperatures, Collections.reverseOrder());
		
		System.out.println("Printing after sorting in descending order:");
		System.out.println(temperatures);
	}
}