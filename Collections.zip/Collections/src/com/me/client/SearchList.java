package com.me.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class SearchList {

	public static void main(String[] args) {
		ArrayList<Integer>numbers = new ArrayList<>();
		Scanner scInput = new Scanner(System.in);
		int number = 0;
		numbers.add(76);
		numbers.add(10);
		numbers.add(78);
		numbers.add(55);
		numbers.add(27);
		
		Collections.sort(numbers);
		
		System.out.print("Input a number: ");
		number = Integer.parseInt(scInput.nextLine());
		
		int position = Collections.binarySearch(numbers, number);
		
		if(position < 0){
			System.out.println("Number not found.");
		}else{
			System.out.println("Number found at position: " + position);
		}
		System.out.println(numbers);
		scInput.close();
	}
}