package com.me.client;

import java.util.Stack;

public class StackDemo {

	public static void main(String[] args) {
		Stack<Integer> stack = new Stack<>();
		
		stack.push(10);
		stack.push(30);
		stack.push(56);

		System.out.println(stack.pop());
	}

}