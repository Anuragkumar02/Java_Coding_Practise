package com.me.client;

import java.util.ArrayList;

public class FindReplace {
	public static void main(String[] args) {
		ArrayList<Integer>numbers = new ArrayList<>();
		
		numbers.add(99);
		numbers.add(100);
		numbers.add(200);
		numbers.add(100);
		
		System.out.println(numbers);
		
		int size = numbers.size();
		
		int num = 0;
		
		for(int i = 0 ; i < size ; i++){
			num = numbers.get(i);
			
			if(num ==200){
				numbers.set(i, 400);
			}
		}

		numbers.add(1,300);
		System.out.println("Using simple for loop:");
		for(int i = 0 ; i < size ; i++){
			num = numbers.get(i);
			System.out.println(num);
		}
	}
}