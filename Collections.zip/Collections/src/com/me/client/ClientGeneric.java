package com.me.client;

import com.me.entity.MyGenericClass;

public class ClientGeneric {

	public static void main(String[] args) {
		Integer i = 10;
		MyGenericClass<String>myGen1 = new MyGenericClass<>();
		myGen1.print("Hello there!");
		
		MyGenericClass<Integer>myGen2 = new MyGenericClass<>();
		myGen2.print(i);
	}
}