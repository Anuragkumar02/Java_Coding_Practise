package com.me.client;

import java.util.Enumeration;
import java.util.Vector;

public class VectorOriginal {
	public static void main(String[] args) {
		Vector<String>numbers = new Vector<String>(3,4);
		//old methods prior to jdk 1.5, in Vector.
		
		numbers.addElement("hi");
		numbers.addElement("hello");
		numbers.addElement("hi");
		numbers.addElement("all the best");
		
		Enumeration<String>enNumbers = numbers.elements();
		
		while(enNumbers.hasMoreElements()){
			System.out.println(enNumbers.nextElement());
		}
		
		numbers.insertElementAt("good morning", 1);//inserted element at position 1
		
		enNumbers = numbers.elements();
		System.out.println("Printing after inserting element:");
		while(enNumbers.hasMoreElements()){
			System.out.println(enNumbers.nextElement());
		}
	}
}