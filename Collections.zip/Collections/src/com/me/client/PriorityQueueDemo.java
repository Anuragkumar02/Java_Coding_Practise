package com.me.client;

import java.util.PriorityQueue;

public class PriorityQueueDemo {

	public static void main(String[] args) {
		PriorityQueue<Integer>prioQueue = new PriorityQueue<>();
		
		prioQueue.add(90);
		prioQueue.add(87);
		prioQueue.add(7);
		prioQueue.add(73);
		prioQueue.add(8);
		prioQueue.add(62);
		
		System.out.println(prioQueue);
	}
}