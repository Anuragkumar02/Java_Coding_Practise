package com.me.client;

import java.util.Collections;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

import com.me.entity.Employee;

public class MapCustomSorted {

	public static void main(String[] args) {
		Map<Integer, Employee>empRecords = new TreeMap<>(Collections.reverseOrder());
		
		Employee employee = null;
		Scanner scInput = new Scanner(System.in);
		
		int empid = 0;
		String name = null;
		float salary = 0.0f;
		
		while(true){
			System.out.print("Enter Employee ID. Enter -999 to stop: ");
			empid = Integer.parseInt(scInput.nextLine());
			
		    if(empid != -999){
		    	System.out.print("Enter Name: ");
				name = scInput.nextLine();
				
				System.out.print("Enter Salary: ");
				salary = Float.parseFloat(scInput.nextLine());
					  	  
				employee = new Employee(empid, name, salary);
				
				empRecords.put(empid, employee);
		    }else{
		    	break;
		    }
		}
		
		Set<Integer>empIds = empRecords.keySet();
		
		for (Integer eid : empIds) {
			System.out.println("Roll No: " + empid + " has "+empRecords.get(eid));
		}
		scInput.close();

	}
}