package com.nareshit.entity;
public class Employee {
	private static int eid = 10;
	
	private int empid = ++eid;
	private String name;
	private float salary;
	private Department department;
	private Address address;
	
	public Employee(String name, float salary, Department department, Address address) {
		super();
		this.name = name;
		this.salary = salary;
		this.department = department;
		this.address = address;
	}
	
	public Employee() {
		super();
	}

	public int getEmpid() {
		return empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getSalary() {
		return salary;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}

	public void output(){
		System.out.println("Employee ID: " + empid);
		System.out.println("Name: " + name);
		System.out.println("Salary: " + salary);
		System.out.println("Department: " + department);
		address.output();
	}
	
	public static void printLast(){
		System.out.println("Last Employee ID: " + eid);
	}
}