package com.nareshit.entity;

public enum Department {
	MARKETING, MANUFACTURING, FINANCE;
}