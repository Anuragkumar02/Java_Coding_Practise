package com.nareshit.client;

import com.nareshit.entity.Arith;

public class ClientArith {

	public static void main(String[] args) {
		Arith arith = new Arith();
		
		System.out.println(arith.add(10, 10));
		System.out.println(arith.add(34.78f, 90.65f));
		System.out.println(arith.add(10, 88.72f));
	}
}