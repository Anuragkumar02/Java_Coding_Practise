package com.nareshit.client;
import java.util.Scanner;

import com.nareshit.entity.Address;
import com.nareshit.entity.Department;
import com.nareshit.entity.Employee;

public class ClientEmployee {

	public static void main(String[] args) {
		
		/*
		 * byte, short, int, long = 0
		 * char = \u0000
		 * float = 0.0f
		 * double = 0.0
		 * boolean = false
		 * reference = null
		 */
		Scanner scInput = new Scanner(System.in);
		
		String name;
		float salary;
		int dept = 0;
		String city;
		String state;
		Address address;
		
		Department department = Department.FINANCE;
		
		Employee.printLast();
		
		System.out.print("Enter name: ");
		name = scInput.nextLine();
		
		System.out.print("Enter salary: ");
		salary = Float.parseFloat(scInput.nextLine());
		
		System.out.println("Enter department:");
		System.out.println("0. Marketing");
		System.out.println("1. Manufacturing");
		System.out.println("2. Finance");
		dept = Integer.parseInt(scInput.nextLine());
		
		switch(dept){
		case 0:
			department = Department.MARKETING;
			break;
		case 1:
			department = Department.MANUFACTURING;
			break;
		case 2:
			department = Department.FINANCE;
			break;
		}
		
		System.out.print("Enter city: ");
		city = scInput.nextLine();
		
		System.out.print("Enter state: ");
		state = scInput.nextLine();
		
		address = new Address(city, state);
		
		Employee empl = new Employee(name, salary, department, address);
				
		System.out.print("Enter name: ");
		name = scInput.nextLine();
		
		System.out.print("Enter salary: ");
		salary = Float.parseFloat(scInput.nextLine());
		
		System.out.println("Enter department:");
		System.out.println("0. Marketing");
		System.out.println("1. Manufacturing");
		System.out.println("2. Finance");
		dept = Integer.parseInt(scInput.nextLine());
		
		System.out.print("Enter city: ");
		city = scInput.nextLine();
		
		System.out.print("Enter state: ");
		state = scInput.nextLine();
		
		address = new Address(city, state);
		
		Employee empNew = new Employee(name, salary, (Department.values()[dept]),address);
		
		empl.output();
		empNew.output();
		
		scInput.close();
		
		name = empNew.getName();
		salary = empNew.getSalary();
		
		System.out.println("Before modification:");
		System.out.println(name + " has " + "salary:Rs." + salary);
		
		empNew.setSalary(350000);
		salary = empNew.getSalary();
		
		System.out.println("After modification:");
		System.out.println(name + " has " + "salary:Rs." + salary);
		
		Employee.printLast();
	}
}