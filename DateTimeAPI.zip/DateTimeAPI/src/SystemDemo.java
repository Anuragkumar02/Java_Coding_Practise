import java.util.Date;

public class SystemDemo {

	public static void main(String[] args) {
		long current = System.currentTimeMillis();
		long currentNano = System.nanoTime();
		
		Date curr = new Date(current);
		//Date currNano = new Date(currentNano);
		
		//System.out.println(currNano);
		System.out.println(curr);
		
		currentNano = System.nanoTime();
		
		for(int i = 1 ; i <= 100000 ; i++);
		
		System.out.println("Time passed because of loop: " + (System.nanoTime() - currentNano));
	}
}