import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class PeriodDurationDemo {

	public static void main(String[] args) {
		LocalDate today = LocalDate.now();
		System.out.println("Today: " + today);
		
		//Enum is a set of constants defined by developer.
		//In a variable of type Enum, only those values can be entered
		//which are part of that defined Enum.
		
		LocalDate nextMonth = today.plus(2, ChronoUnit.MONTHS);
		System.out.println("Next Month: "+nextMonth);
		
		Period period = Period.between(nextMonth, today);
		System.out.println(period);
		
		LocalTime now = LocalTime.now();
		Duration duration = Duration.ofHours(2);
		LocalTime newTime = now.plus(duration);
		
		System.out.println(newTime);
	}
}