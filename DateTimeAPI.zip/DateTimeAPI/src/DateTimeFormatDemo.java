import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class DateTimeFormatDemo {
	public static void main(String[] args) {
		ZonedDateTime zdt = ZonedDateTime.parse("2017-08-06T16:45:30+00:30[Asia/Calcutta]");
		
		DateTimeFormatter formatter = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.LONG);
		System.out.println(formatter.format(zdt));
		
		formatter = DateTimeFormatter.ofPattern("EEEE yyyy-MMM-dd");
		System.out.println(formatter.format(zdt));
	}
}