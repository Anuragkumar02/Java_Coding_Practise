import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;

public class DateTimeTester {
	public static void main(String[] args) {
		LocalDateTime currentTime = LocalDateTime.now();
		System.out.println("The current date time is: " + currentTime);
		
		LocalDate d1 = currentTime.toLocalDate();
		System.out.println("Today's date: " + d1);
		
		Month month = currentTime.getMonth();
		System.out.println("Current month: " + month);
		
		int dayOfMonth = currentTime.getDayOfMonth();
		System.out.println("Day of Month: " + dayOfMonth);
		
		int seconds = currentTime.getSecond();
		System.out.println("Seconds: " + seconds);
		
		LocalDateTime newDate = currentTime.withDayOfMonth(9).withYear(2017);
		System.out.println("New Date time: " + newDate);
		
		LocalDate onlyDate = LocalDate.of(2017, Month.JANUARY, 15);
		System.out.println("Date: " + onlyDate);
		
		LocalTime myTime = LocalTime.of(16, 30);
		System.out.println(myTime);
		
		LocalTime yesTime = LocalTime.parse("21:45:55");
		System.out.println(yesTime);
	}
}