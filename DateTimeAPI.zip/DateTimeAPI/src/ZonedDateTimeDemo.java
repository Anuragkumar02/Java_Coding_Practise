import java.time.ZoneId;
import java.time.ZonedDateTime;

public class ZonedDateTimeDemo {

	public static void main(String[] args) {
		ZonedDateTime zdt = ZonedDateTime.parse("2017-05-06T16:45:30+00:30[Europe/Paris]");
		System.out.println(zdt);

		ZoneId zoneId = ZoneId.of("Europe/Paris");
		System.out.println(zoneId);
		
		ZoneId whereAmI = ZoneId.systemDefault();
		System.out.println(whereAmI);
	}
}