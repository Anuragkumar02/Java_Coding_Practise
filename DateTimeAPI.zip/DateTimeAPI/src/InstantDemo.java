import java.time.Duration;
import java.time.Instant;

public class InstantDemo {

	public static void main(String[] args) {
		Instant current = Instant.now();
		
		for(int i = 1 ; i <= 100000000; i++);
		
		Instant now = Instant.now();
		
		Duration differenceInMillis = Duration.between(current, now);
		
		System.out.println("Difference in milliseconds: " + differenceInMillis.toMillis());
	}
}