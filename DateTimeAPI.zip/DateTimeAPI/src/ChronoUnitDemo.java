import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class ChronoUnitDemo {

	public static void main(String[] args) {
		LocalDate today = LocalDate.now();
		System.out.println("Today: " + today);
		
		LocalDate nextWeek = today.plus(1, ChronoUnit.WEEKS);
		System.out.println("Next Week: "+nextWeek);
		
		LocalDate nextMonth = today.plus(1, ChronoUnit.MONTHS);
		System.out.println("Next Month: "+nextMonth);
		
		LocalDate nextYear = today.plus(1, ChronoUnit.YEARS);
		System.out.println("Next Year: "+nextYear);
		
		LocalDate nextDecade = today.plus(1, ChronoUnit.DECADES);
		System.out.println("Next Decade: "+nextDecade);
	}
}