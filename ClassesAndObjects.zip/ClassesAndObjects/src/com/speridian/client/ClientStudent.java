package com.speridian.client;
import java.util.Scanner;

import com.speridian.entity.Address;
import com.speridian.entity.Student;

public class ClientStudent {

	public static void main(String[] args) {

		Student studentOne = null;
		Student studentTwo = null;
		Address address = null;
		
		Student.getCount();
		
		String name = null;
		float percent = 0.0f;
		
		String city = null;
		String state = null;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter name: ");
		name = scInput.nextLine();
		
		System.out.print("Enter percent: ");
		percent = Float.parseFloat(scInput.nextLine());
		
		System.out.print("Enter city: ");
		city = scInput.nextLine();
		
		System.out.print("Enter state: ");
		state = scInput.nextLine();
		
		address = new Address(city,state);
		
		studentOne = new Student(name, percent, address);

		System.out.print("Enter name: ");
		name = scInput.nextLine();
		
		System.out.print("Enter percent: ");
		percent = Float.parseFloat(scInput.nextLine());
		
		System.out.print("Enter city: ");
		city = scInput.nextLine();
		
		System.out.print("Enter state: ");
		state = scInput.nextLine();
		
		address = new Address(city,state);
		
		studentTwo = new Student(name, percent, address);
		
		studentOne.print();
		studentTwo.print();
		
		Student.getCount();
		
		scInput.close();
	}
}