package com.speridian.client;

import java.util.Scanner;

import com.speridian.entity.Address;
import com.speridian.entity.Student;

public class ClientStudentArray {

	public static void main(String[] args) {
		Student students[] = new Student[2]; 
		Address address = null;
		
		String name = null;
		float percent = 0.0f;
		
		String city = null;
		String state = null;
		
		Scanner scInput = new Scanner(System.in);
		
		for (int i = 0; i < students.length; i++) {
			System.out.print("Enter name: ");
			name = scInput.nextLine();
			
			System.out.print("Enter percent: ");
			percent = Float.parseFloat(scInput.nextLine());
			
			System.out.print("Enter city: ");
			city = scInput.nextLine();
			
			System.out.print("Enter state: ");
			state = scInput.nextLine();
			
			address = new Address(city,state);	
			
			students[i] = new Student(name, percent, address);
		}

		for (int i = 0; i < students.length; i++) {
			students[i].print();
		}
		
		scInput.close();
	}
}