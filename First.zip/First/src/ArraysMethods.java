import java.util.Arrays;

public class ArraysMethods {

	public static void main(String[] args) {
		int arr[] = {44,3,63,15,77,56};
		
		System.out.println("Array before sorting");
		
		for(int i = 0 ; i < arr.length ; i++){
			System.out.print(arr[i]+"\t");
		}
		
		Arrays.sort(arr);
		
		System.out.println("\nArray after sorting");
		
		for(int i = 0 ; i < arr.length ; i++){
			System.out.print(arr[i]+"\t");
		}
	}
}