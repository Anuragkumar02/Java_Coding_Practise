
public class LeftShift {

	public static void main(String[] args) {
		int number = 12;//0000 1100
		int shift = 3;

		//0110 0000
		
		int result = number << shift;
		/*
		 * number << shift ==> number * 2 raised to shift
		 */
		System.out.println(result);
	}
}