
public class ForLoop {

	public static void main(String[] args) {
	//int i = 1;
  //Initialization ; test   ; increment/decrement part	
		for(int i = 1, j = 10;  ; ){
			if(i <= 10){
			System.out.println(i+"\t"+j);
			i++;
			j--;
			}else{
				break;//go out of current loop.
			}
			/*System.out.println(i);
			i++;*/
			//System.out.println(i);
		}
	}
}
/*
 * 1
 * 2
 * 3
 */
