import java.util.Scanner;

public class SumRowwise {

	public static void main(String[] args) {
		int a[][];
		
		int rows = 0;
		int cols = 0;
		
		int sumRowWise = 0;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter no. of rows: ");
		rows = scInput.nextInt();
		
		System.out.print("Enter no. of columns: ");
		cols = scInput.nextInt();
		
		a = new int[rows][cols];
		
		//Input the double dimensional array.
		for (int row = 0; row < a.length; row++) {
			sumRowWise = 0;
			for(int col = 0 ; col < a[row].length;col++){
				System.out.print("Enter an element: ");
				a[row][col] = scInput.nextInt();
				//sumRowWise += a[row][col];
			}
			//System.out.println("Sum of row no. "+(row+1) + " is " + sumRowWise);
		}
		
		//Summing row-wise & then printing
		
		for (int row = 0; row < a.length; row++) {
			sumRowWise = 0;
			for(int col = 0 ; col < a[row].length;col++){
				sumRowWise += a[row][col];
			}
			System.out.println("Sum of row no. "+(row+1) + " is " + sumRowWise);
		}
		
		scInput.close();
	}
}