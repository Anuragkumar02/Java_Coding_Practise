import java.util.Scanner;

public class MaxInDobArray {

	public static void main(String[] args) {
		int a[][];
		
		int rows = 0;
		int cols = 0;
		
		int maximum = 0;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter no. of rows: ");
		rows = scInput.nextInt();
		
		System.out.print("Enter no. of columns: ");
		cols = scInput.nextInt();
		
		a = new int[rows][cols];
		
		for (int row = 0; row < a.length; row++) {
			for(int col = 0 ; col < a[row].length;col++){
				System.out.print("Enter an element: ");
				a[row][col] = scInput.nextInt();
				
				if(a[row][col] > maximum){
					maximum = a[row][col];
				}
			}
		}
		
		/*for (int row = 0; row < a.length; row++) {
			for(int col = 0 ; col < a[row].length;col++){
				
			}
		}*/
		System.out.println("The largest element is: " + maximum);
		scInput.close();
	}
}