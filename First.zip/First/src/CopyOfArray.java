import java.util.Arrays;

public class CopyOfArray {
	public static void main(String[] args) {
		int a[] = {2,90,36,71,52};
		
		int b[];
		
		b = Arrays.copyOf(a, 2);
		
		System.out.println("Printing array A:");
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
		
		System.out.println("Printing array B:");
		for (int i = 0; i < b.length; i++) {
			System.out.println(b[i]);
		}
		
		b = Arrays.copyOfRange(a, 1, 4);
		
		System.out.println("Printing updated array B:");
		for (int i = 0; i < b.length; i++) {
			System.out.println(b[i]);
		}
	}
}