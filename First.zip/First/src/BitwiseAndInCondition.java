
public class BitwiseAndInCondition {

	public static void main(String[] args) {
		int x = 3;
		int y = 5;
		
		if(x == 3 ^ y++ == 5){
			System.out.println("Correct!");
		}else{
			System.out.println("Incorrect!");
		}
		
		System.out.println(y);
	}
}