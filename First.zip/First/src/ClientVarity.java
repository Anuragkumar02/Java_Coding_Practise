
public class ClientVarity {

	public static void main(String[] args) {
		VarityArgDemo vad = new VarityArgDemo();
		
		int sum = vad.add(1,2,3);
		System.out.println(sum);
		
		sum = vad.add(1,2);
		System.out.println(sum);
		
		sum = vad.add();
		System.out.println(sum);
	}
}