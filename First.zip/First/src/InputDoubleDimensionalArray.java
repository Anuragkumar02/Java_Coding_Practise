import java.util.Scanner;

public class InputDoubleDimensionalArray {
	public static void main(String[] args) {
		int a[][];
		
		int rows = 0;
		int cols = 0;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter no. of rows: ");
		rows = scInput.nextInt();
		
		System.out.print("Enter no. of columns: ");
		cols = scInput.nextInt();
		
		a = new int[rows][cols];
		
		for (int row = 0; row < a.length; row++) {
			for(int col = 0 ; col < a[row].length;col++){
				System.out.print("Enter an element: ");
				a[row][col] = scInput.nextInt();
			}
		}
		
		for (int row = 0; row < a.length; row++) {
			for(int col = 0 ; col < a[row].length;col++){
				System.out.print(a[row][col]+"\t");
			}
			System.out.println();
		}
		
		scInput.close();
	}
}