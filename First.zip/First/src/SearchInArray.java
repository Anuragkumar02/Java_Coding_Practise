import java.util.Arrays;
import java.util.Scanner;

public class SearchInArray {

	public static void main(String[] args) {
		int arr[] = {44,3,63,15,77,56};
		int number = 0;
		int index = 0;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter number to be searched: ");
		number = scInput.nextInt();
		
		System.out.println("Array before sorting");
		
		for(int i = 0 ; i < arr.length ; i++){
			System.out.print(arr[i]+"\t");
		}
		
		Arrays.sort(arr);
		
		System.out.println("\nArray after sorting");
		
		for(int i = 0 ; i < arr.length ; i++){
			System.out.print(arr[i]+"\t");
		}
		System.out.println();
		index = Arrays.binarySearch(arr, number);
		
		if(index < 0){
			System.out.println("Number not found.");
		}else{
			System.out.println("Number found at position " + index);
		}
		
		scInput.close();
	}
}