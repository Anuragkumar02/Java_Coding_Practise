import static java.lang.System.out;
public class First {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*byte number = 40;
		int num = 40;
		
		num = 10;
		number += num;//number = number + num
		
		out.println(number);
		out.println(num);*/
		
		out.println(average());
		out.println(average(13,45));
		out.println(average(56,67,78));
	}
	
	public static float average(float... temperatures){
		float avg = 0.0f;
		
		for(int i = 0 ; i < temperatures.length ; i++){
			avg += temperatures[i];
		}
		
		avg /= temperatures.length;
		
		return avg;
	}
}