
public class ModuloDemo {

	public static void main(String[] args) {
		double number = 10.24;
		double divisor = 3.35;
		//Modulo operator in Java, is even applicable to floats & doubles.
		//unlike only integers in other programming language.
		
		double remainder = number % divisor;
		
		System.out.printf("Remainder is:%-5.2f",remainder);
	}
}