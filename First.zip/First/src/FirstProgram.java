
public class FirstProgram {
	public static void main(String[] args) {
		System.out.println("Oh no! Not Hello World Again!!");
	}
}