import java.util.Scanner;

public class Switch {

	public static void main(String[] args) {
		int number = 0;
				
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter a number between 0 to 9: ");
		number = scInput.nextInt();
		
		final int value = 9;
		/*
		 * only byte, short, int, char in switch
		 */
		switch(number){
		case 3:
			System.out.println("Three");
			//break;
		case 0:
			System.out.println("Zero");
			break;
		default:
			System.out.println("Invalid Number.");
			break;
		case 1:
			System.out.println("One");
			break;
		case 2:
			System.out.println("Two");
			break;
		case 4:
			System.out.println("Four");
			break;
		case 5:
			System.out.println("Five");
			break;
		case 6:
			System.out.println("Six");
			break;
		case 7:
			System.out.println("Seven");
			break;
		case 8:
			System.out.println("Eight");
			break;
		case value:
			System.out.println("Nine");
			break;
		}
		scInput.close();
	}
}