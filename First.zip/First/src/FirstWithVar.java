
public class FirstWithVar {

	public static void main(String[] args) {
		byte age = 0;
		
		boolean isThereGravityOnMars = true;
		
		char ch = 'k';
		
		float percentage = 67.56F;
		
		double temperature = 56876.679;
		
		System.out.println("Age is: " + age);
		System.out.println("Is there gravity on Mars? " + isThereGravityOnMars);
		System.out.println("Character contains: " + ch);
		System.out.println("Percentage: " + percentage);
		System.out.println("Temperature: " + temperature);
	}
}