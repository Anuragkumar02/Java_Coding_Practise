
public class DoubleDimensionalArray {

	public static void main(String[] args) {
		int a[][] = {
				{1,2,3,4},
				{5,6,7,8},
				{9,0,1,2}
			};
		/*int []b[];
		int[][] c;*/
		
		//One way of initializing double dimensional array.
		/*a = new int[][]{
			{1,2,3,4},
			{5,6,7,8},
			{9,0,1,2}
		};*///3 rows & 4 columns.
		
		for (int row = 0; row < a.length; row++) {//No. of rows
			for(int col = 0 ; col < a[row].length;col++){//No. of columns in that row.
				System.out.print(a[row][col]+"\t");
			}
			System.out.println();
		}
	}
}