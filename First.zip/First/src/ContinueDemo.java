
public class ContinueDemo {

	public static void main(String[] args) {
		for(int i = 1 ; i <= 10 ; i++){
			if( i == 3 ){
				continue;//go to next repetition.
			}
			System.out.println(i);
		}
	}
}