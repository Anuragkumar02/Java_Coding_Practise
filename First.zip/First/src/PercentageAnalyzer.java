import java.util.Scanner;

public class PercentageAnalyzer {

	public static void main(String[] args) {
		int marks = 0;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter percentage: ");
		marks = scInput.nextInt();
		
		if(marks >= 75){
			System.out.println("Distinction.");
		}
		
		else if(marks >= 60 && marks < 75){
			System.out.println("First Class");
		}
		
		else if(marks >= 50 && marks < 60){
			System.out.println("Second Class");
		}
		
		else if(marks >= 40 && marks < 50){
			System.out.println("Pass Class");
		}
		
		else{
			System.out.println("Fail.");
		}
		
		scInput.close();
	}
}