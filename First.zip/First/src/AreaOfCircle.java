import static java.lang.System.out;

public class AreaOfCircle {

	public static void main(String[] args) {
		double radius = 10.24;
		double area = Math.PI * radius * radius;
		
		out.println("Area: "+area);
	}
}