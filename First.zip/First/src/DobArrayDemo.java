
public class DobArrayDemo {
	public static void main(String[] args) {
		int a[][];
		/*int[] b[];
		int []c[];*/
		
		a = new int[][]{
			{1,2,3},
			{4,5,6},
			{7,8,9}
		};
		
		for(int row = 0 ; row < a.length ; row++){//a.length means no. of rows
			for(int col = 0 ; col < a[row].length ; col++){//length of individual row.
				System.out.print(a[row][col]+"\t");
			}
			System.out.println();
		}
	}
}