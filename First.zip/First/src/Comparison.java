import java.util.Scanner;

public class Comparison {

	public static void main(String[] args) {
		int age = 0;
		int experience = 0;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter age of the driver: ");
		age = scInput.nextInt();
		
		System.out.print("Enter experience of the driver: ");
		experience = scInput.nextInt();
		
		if(age > 30 && experience >= 5)
			System.out.println("Driver is selected.");
		else
			System.out.println("Driver not selected.");
		
		scInput.close();
	}
}