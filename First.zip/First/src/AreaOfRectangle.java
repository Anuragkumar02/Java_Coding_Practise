
public class AreaOfRectangle {
	public static void main(String[] args) {
		float length = 12.66756f;
		float breadth = 34.76887f;
		
		float area = length * breadth;
		
		System.out.println("Area is: " + area);
	}
}