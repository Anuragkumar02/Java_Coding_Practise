
public class ExperimentIncrement {

	public static void main(String[] args) {
		int number = 2;
		
		int result = number++ * number++ * number++;
		
		System.out.println("Number: " + number);
		System.out.println("Result: " + result);
	}
}