
public class TernaryDemo {

	public static void main(String[] args) {
		int number = 10;
		int another = 20;
		
		int result = (number > another)?number:another;
		//Below is syntactical error in Java
//(number > another)?System.out.println(number):System.out.println(number);
		System.out.println(result);
	}
}