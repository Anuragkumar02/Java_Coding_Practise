import java.util.Scanner;

public class OrOperator {

	public static void main(String[] args) {
	int number = 0;
	
	Scanner scInput = new Scanner(System.in);
	
	System.out.print("Enter a number: ");
	number = scInput.nextInt();
	
	if(number == 21 || number == 42){
		System.out.println("You are lucky today.");
	}else{
		System.out.println("Hard luck! Better luck next time!!");
	}
	
	scInput.close();
	}
}