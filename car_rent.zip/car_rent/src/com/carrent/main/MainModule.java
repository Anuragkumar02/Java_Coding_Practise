package com.carrent.main;

import java.util.Scanner;

public class MainModule {

	public static void main(String[] args) {

		int choice = -1;
		int innerChoice = -1;

		Scanner scInput = new Scanner(System.in);

		while (choice != 0) {

			System.out.println("Following are the options:");
			System.out.println("1. Customer");
			System.out.println("2. Vehicle");
			System.out.println("3. Reservation");
			System.out.println("4. Admin");
			System.out.println("0. Exit");
			System.out.print("Please enter your choice: ");

			choice = scInput.nextInt();

			switch (choice) {
			case 1:
				while (innerChoice != 0) {
					System.out.println("Following are the options:");
					System.out.println("1. Insert Customer");
					System.out.println("2. Update Customer");
					System.out.println("3. Delete Customer");
					System.out.println("4. View customer by ID");
					System.out.println("5. View all customers");
					System.out.println("0. Exit");
					System.out.print("Please enter your choice: ");

					innerChoice = scInput.nextInt();

					switch (innerChoice) {
					case 1:
						System.out.println("You have chosen insertion of customer.");
						break;
					default:
						System.out.println("Incorrect option");
						break;
					}
				}
			}
		}

		scInput.close();

	}

}
