package com.me.entity;

public class MyPerfectLodge implements IPerfectLodge {

	@Override
	public void calcFoodBill() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calcTaxiService() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calculateRoomBill() {
		// TODO Auto-generated method stub

	}

}
