package com.me.entity;

public interface IntAJava8 {
	default public void methodA() {

	}

	
	default public void methodB() {

	}


	default public void methodC() {

	}

	
	default public void methodD() {

	}


	default public void methodE() {
	}

	default public void methodF() {

	}

	default public void methodG() {

	}

	default public void methodH() {

	}

	default public void methodI() {

	}

	default public void methodJ() {

	}
	
	static double returnGravity(){
		return 9.8;
	}
}