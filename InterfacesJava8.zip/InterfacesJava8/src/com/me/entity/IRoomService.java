package com.me.entity;

public interface IRoomService {
	void calculateRoomBill();
}