package com.me.entity;

public interface IPerfectLodge extends ITaxiService, IRoomService, IFoodService {
}