package com.me.entity;

public class Lodge3 implements IRoomService, ITaxiService {

	@Override
	public void calcTaxiService() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calculateRoomBill() {
		// TODO Auto-generated method stub

	}

}
