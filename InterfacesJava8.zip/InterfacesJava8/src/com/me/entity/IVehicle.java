package com.me.entity;

public interface IVehicle {
	void accelerate();
	void applyBrakes();
}