package com.me.entity;

public class Lodge2 implements IRoomService, IFoodService {

	@Override
	public void calcFoodBill() {

	}

	@Override
	public void calculateRoomBill() {

	}

}
