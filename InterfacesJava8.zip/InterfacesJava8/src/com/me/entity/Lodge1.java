package com.me.entity;

public class Lodge1 implements IPerfectLodge {

	@Override
	public void calcTaxiBill() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calculateRoomBill() {
		// TODO Auto-generated method stub

	}

}
