package com.me.entity;

public class Lodge implements IRoomService{
	private static final float NONAC = 850;
	private static final float AC = 1100;
	
	private int days;
	private String type;
	
	private float bill;
	
	public Lodge(int days, String type) {
		super();
		this.days = days;
		this.type = type;
	}

	@Override
	public void calculateRoomBill() {
		if(this.type.equalsIgnoreCase("nonac")){
			this.bill = NONAC * days;
		}else if(this.type.equalsIgnoreCase("ac")){
			this.bill = AC * days;
		}
	}

	@Override
	public String toString() {
		return "Lodge [days=" + days + ", type=" + type + ", bill=" + bill + "]";
	}

	
}
