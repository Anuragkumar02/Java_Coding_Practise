package com.me.entity;

public class Circle implements IShape {
	private float radius;
	private float area;
	private float perimeter;
	
	public Circle(float radius) {
		this.radius = radius;
	}

	@Override
	public void calcArea() {
		this.area = 3.14f * this.radius * this.radius;
	}

	@Override
	public void calcPerimeter() {
		this.perimeter = 2 * 3.14f * this.radius;
	}

	@Override
	public String toString() {
		return "Circle [radius=" + radius + ", area=" + area + ", perimeter=" + perimeter + "]";
	}
}