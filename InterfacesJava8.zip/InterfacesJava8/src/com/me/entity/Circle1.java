package com.me.entity;

public class Circle1 implements IShape {

	@Override
	public void calcArea() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calcPerimeter() {
		// TODO Auto-generated method stub
		
	}

}