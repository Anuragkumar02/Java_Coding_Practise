package com.me.entity;

public class BAdapter implements IntB {

	@Override
	public void methodA() {
		// TODO Auto-generated method stub

	}

	@Override
	public void methodB() {
		// TODO Auto-generated method stub

	}

	@Override
	public void methodC() {
		// TODO Auto-generated method stub

	}

}
