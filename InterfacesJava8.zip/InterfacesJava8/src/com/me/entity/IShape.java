package com.me.entity;

public interface IShape {
	double PI = 3.14;//public static final, by default. This cannot be changed.
	void calcArea();//I don't need to declare that it is public & abstract. By default & permanent.
	void calcPerimeter();//I don't need to declare that it is public & abstract.
}