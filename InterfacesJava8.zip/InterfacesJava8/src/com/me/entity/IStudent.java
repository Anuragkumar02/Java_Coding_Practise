package com.me.entity;

public interface IStudent {
	static int count = 0;
	
	int calculateTotal();
	
	default float calculatePercent(){
		return 100;
	}
	
	static void printCount(){
		System.out.println("Count: " + count);
	}
}