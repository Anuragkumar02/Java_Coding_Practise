package com.me.entity;

public class IntBImpl1 implements IntB {
	public void methodA(){
		
	}
	
}