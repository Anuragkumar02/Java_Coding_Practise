package com.me.entity;

public interface Volume {
	float PI = 3.14f;
	void printArea();
	void printVolume();
}
