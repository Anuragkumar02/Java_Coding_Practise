package com.me.client;

import com.me.entity.Bicycle;
import com.me.entity.IVehicle;
import com.me.entity.MotorCycle;

public class ClientInterfaces {

	public static void main(String[] args) {
		IVehicle vehicle = new Bicycle();
		vehicle.accelerate();
		vehicle.applyBrakes();
		
		vehicle = new MotorCycle();
		vehicle.accelerate();
		vehicle.applyBrakes();
	}
}