package com.me.client;

import com.me.entity.IntAJava8;

public class TryJava8Interface {

	public static void main(String[] args) {
		
		System.out.println(IntAJava8.returnGravity());
	}
}