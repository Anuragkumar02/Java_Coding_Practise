package programs;

public class StringMethods2 {
	public static void main(String[] args) {
		String text = "You can fool some people all the time,\n"+
				  "You can fool all people for some time,\n"+
				  "But you cannot fool all people all time.";
		
		boolean doesThatStart = text.startsWith("You");
		System.out.println("Does that start with 'You': "+doesThatStart);
		
		boolean doesThatEnd = text.endsWith("time.");
		System.out.println("Does that end with 'time.': "+doesThatEnd);
		
		String substr = text.substring(4, 7);
		System.out.println(substr);
		
		substr = text.substring(7);
		System.out.println(substr);
		
		char ch = text.charAt(2);
		System.out.println(ch);
		
		int length = text.length();
		System.out.println("Length: " + length);
		
		String str = new String("naresh it");
		String str1 = new String("Naresh It");
		
		if(str == str1){//Compares object references & not the contents.
			System.out.println("They are same object.");
		}else{
			System.out.println("They are different objects.");
		}
		if(str.equals(str1)){//Compares contents & returns true/false.
			System.out.println("They are equal.");
		}else{
			System.out.println("They are not equal.");
		}
		
		if(str.equalsIgnoreCase(str1)){
		//Compares contents ignoring case & returns true/false.
			System.out.println("They are equal.");
		}else{
			System.out.println("They are not equal.");
		}
		
		if(str.compareTo(str1) > 0){
			System.out.println("First is greater.");
		}else if(str.compareTo(str1) < 0){
			System.out.println("Second is greater.");
		}else{
			System.out.println("Both are same.");
		}
	}
}