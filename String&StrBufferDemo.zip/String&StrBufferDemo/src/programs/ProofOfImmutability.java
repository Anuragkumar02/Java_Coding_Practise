package programs;

public class ProofOfImmutability {

	public static void main(String[] args) {
		String str = new String("abc");
		String str1 = str;
		
		if(str == str1){
			System.out.println("Both refer to same object.");
		}else{
			System.out.println("Both refer to different objects.");
		}
		
		str1 = " def";//str1.concat(" def");
		
		if(str == str1){
			System.out.println("Both refer to same object.");
		}else{
			System.out.println("Both refer to different objects.");
		}
		
		System.out.println(str);
		System.out.println(str1);
	}
}