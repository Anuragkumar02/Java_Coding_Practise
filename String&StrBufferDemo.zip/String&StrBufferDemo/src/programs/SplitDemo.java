package programs;

public class SplitDemo {
	public static void main(String[] args) {
		String str = new String("Hello  there!  Hi!!");
		
		String words[] = str.split(" ");
		
		for (int i = 0; i < words.length; i++) {
			System.out.println(words[i]);
		}
	}
}