package programs;

import java.util.StringTokenizer;

public class StringTokenizerDemo {

	public static void main(String[] args) {
		String str = new String("Hello, there!, Hi!!");
		//Legacy class present since jdk 1.1
		StringTokenizer stt = new StringTokenizer(str,",");
		
		while(stt.hasMoreTokens()){
			String splitted = stt.nextToken();
			System.out.println(splitted);
		}
		System.out.println("When no delimiter:");
		stt = new StringTokenizer(str);//Space is default delimiter.
		
		while(stt.hasMoreTokens()){
			String splitted = stt.nextToken();
			System.out.println(splitted);
		}
	}
}