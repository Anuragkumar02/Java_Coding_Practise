package programs;

public class StringDemo {

	public static void main(String[] args) {
		String text = new String("abc");
		String blank = new String();//Contains nothing
		
		byte alphabets[] = {65,65,65};
		String bytes = new String(alphabets);
		
		char chars[] = {'y','o','u'};
		String str = new String(chars);
		//There are at least a dozen constructors on String, just google'em.
		
		System.out.println(text);
		System.out.println(blank);
		System.out.println(bytes);
		System.out.println(str);
	}
}