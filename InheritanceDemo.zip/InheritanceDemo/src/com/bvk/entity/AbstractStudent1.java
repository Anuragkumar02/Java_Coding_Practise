package com.bvk.entity;

public abstract class AbstractStudent1 {

}