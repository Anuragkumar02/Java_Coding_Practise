package com.bvk.entity;

public class ExtraCurricular {

}
