package com.bvk.entity;

public abstract class PermanentEmployee extends AbstractEmployee {

}