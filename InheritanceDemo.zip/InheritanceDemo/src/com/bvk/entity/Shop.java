package com.bvk.entity;

public class Shop {
	private int shopId;
	private String name;
	private float profit;
	private float tax;
	protected float profitAfterTax;//profit - tax
	
	public Shop() {
	}

	public Shop(int shopId, String name, float profit, float tax) {
		this.shopId = shopId;
		this.name = name;
		this.profit = profit;
		this.tax = tax;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getProfit() {
		return profit;
	}

	public void setProfit(float profit) {
		this.profit = profit;
	}

	public float getTax() {
		return tax;
	}

	public void setTax(float tax) {
		this.tax = tax;
	}

	public float getProfitAfterTax() {
		return profitAfterTax;
	}

	public void setProfitAfterTax(float profitAfterTax) {
		this.profitAfterTax = profitAfterTax;
	}
	
	public void calculate(){
		this.profitAfterTax = this.profit - this.tax;
	}
	
	/*public void output(){
		System.out.println("Shop ID: " + shopId);
		System.out.println("Name: " + name);
		System.out.println("Profit: " + profit);
		System.out.println("Tax: " + tax);
		System.out.println("Profit After Tax: " + profitAfterTax);
	}*/
	@Override
	public String toString(){
		String text = "Shop ID: " + shopId + "\n" +
					  "Shop Name: " + name + "\n" +
					  "Profit: " + profit + "\n" +
					  "Tax: " + tax + "\n" +
					  "Profit After Tax: " + profitAfterTax + "\n" +
					  "==========================================";
		
		return text;
	}
}