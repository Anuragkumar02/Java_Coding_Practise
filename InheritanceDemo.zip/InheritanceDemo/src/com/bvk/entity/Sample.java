package com.bvk.entity;

public class Sample {
	private void methodA(){
		int a[][] = new int[3][4];
		System.out.println("Inside private method.");
	}
	
	public void methodB(){
		System.out.println("Inside public method.");
		methodA();
	}
}