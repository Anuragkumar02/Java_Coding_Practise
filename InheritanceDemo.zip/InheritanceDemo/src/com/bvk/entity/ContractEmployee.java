package com.bvk.entity;

public class ContractEmployee extends AbstractEmployee {

	@Override
	public void calculateSalary() {
		// TODO Auto-generated method stub

	}
}