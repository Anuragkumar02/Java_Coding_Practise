package com.bvk.entity;

public class Emp {
	int empid;
}
