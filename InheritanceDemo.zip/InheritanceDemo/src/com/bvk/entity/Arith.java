package com.bvk.entity;

public class Arith {
	
	public int add(int a, int b){
		System.out.println("add of int called");
		return (a+b);
	}
	
	public float add(float a, float b){
		System.out.println("add of float called");
		return (a+b);
	}
}