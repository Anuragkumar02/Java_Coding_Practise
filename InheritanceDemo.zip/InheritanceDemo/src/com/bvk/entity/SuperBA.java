package com.bvk.entity;

public class SuperBA extends BA {

}