package com.bvk.client;

import com.bvk.entity.Sample;

public class ClientSample {

	public static void main(String[] args) {
		Sample s = new Sample();
		s.methodB();
	}
}