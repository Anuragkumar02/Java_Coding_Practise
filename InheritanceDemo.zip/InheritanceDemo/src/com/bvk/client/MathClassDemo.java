package com.bvk.client;

public class MathClassDemo {

	public static void main(String[] args) {
		int max = Math.max(10, 20);
		System.out.println(max);
		
		int min = Math.min(10, 20);
		System.out.println(min);
		
		double root = Math.sqrt(100);
		System.out.println(root);
		
		double ceil = Math.ceil(4.2);
		System.out.println(ceil);
		
		double floor = Math.floor(4.2);
		System.out.println(floor);
		
		double square = Math.pow(10, 2);
		System.out.println(square);
		
	}
}