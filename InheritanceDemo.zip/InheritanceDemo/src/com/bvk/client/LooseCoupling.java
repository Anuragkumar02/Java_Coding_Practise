package com.bvk.client;

public class LooseCoupling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
