package com.bvk.client;

import com.bvk.entity.AbstractStudent;
import com.bvk.entity.BA;
import com.bvk.entity.MBA;

public class ClientStudent {
	public static void main(String[] args) {
		BA ba = new BA();
		MBA mba = new MBA();
		//AbstractStudent as = new BA();
		ba.input();
		mba.input();
		
		ba.calculateTotal();
		mba.calculateTotal();
		
		System.out.println(ba);
		System.out.println(mba);
		
		if(ba instanceof BA){
			System.out.println("Object of BA");
		}
		
		if(ba instanceof AbstractStudent){
			System.out.println("Object of AbstractStudent");
		}
	}
}