package com.bvk.client;

public class UncheckedDemo {

	public static void main(String[] args) {
		int a[] = {10,20,30};
		
		for(int i = 0 ; i < a.length ; i++){
			System.out.println(a[i]);
		}
		
/*		String str = new String("Hi! how are u?");
		
		if(str.startsWith("Hi!")){
			System.out.println("Hi!");
		}*/
	}
}