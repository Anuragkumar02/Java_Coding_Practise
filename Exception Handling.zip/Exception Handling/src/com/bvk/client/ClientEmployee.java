package com.bvk.client;

import com.bvk.entity.Employee;

public class ClientEmployee {
	public static void main(String[] args) {
		Employee e = new Employee(1, "abc", 35000, 15000, 10000, 4000, 1200);
		e.calcSalary();
		System.out.println(e);
	}
}