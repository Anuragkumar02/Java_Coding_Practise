package com.me.client;

public class RangeOfValues {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Minimum Byte value: " + Byte.MIN_VALUE);
		System.out.println("Maximum Byte value: " + Byte.MAX_VALUE);
		System.out.println("Number of bits for Byte: " + Byte.SIZE+"\n");
		
		System.out.println("Minimum Short value: " + Short.MIN_VALUE);
		System.out.println("Maximum Short value: " + Short.MAX_VALUE);
		System.out.println("Number of bits for Short: " + Short.SIZE+"\n");
		
		System.out.println("Minimum Integer value: " + Integer.MIN_VALUE);
		System.out.println("Maximum Integer value: " + Integer.MAX_VALUE);
		System.out.println("Number of bits for Integer: " + Integer.SIZE+"\n");
		
		System.out.println("Minimum Long value: " + Long.MIN_VALUE);
		System.out.println("Maximum Long value: " + Long.MAX_VALUE);
		System.out.println("Number of bits for Long: " + Long.SIZE+"\n");
		
		System.out.println("Minimum Float value: " + Float.MIN_VALUE);
		System.out.println("Maximum Float value: " + Float.MAX_VALUE);
		System.out.println("Number of bits for Float: " + Float.SIZE+"\n");
		
		System.out.println("Minimum Double value: " + Double.MIN_VALUE);
		System.out.println("Maximum Double value: " + Double.MAX_VALUE);
		System.out.println("Number of bits for Double: " + Double.SIZE+"\n");
		
		System.out.println("True value in Boolean: " + Boolean.TRUE);
		System.out.println("False value in Boolean: " + Boolean.FALSE);
	}
}