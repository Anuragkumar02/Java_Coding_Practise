package com.me.client;

import java.util.Date;

public class Mock1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*char[] vowels = {'a','e','i','o','u'};
		int[] flags = new int[5];
		int count = 0;
				
		char[] str = args[0].toCharArray();
		
		for(int i = 0 ; i < vowels.length; i++){
			for(int j = 0 ; j < str.length ; j++){
				if(vowels[i] == str[j]){
					count++;
					flags[i] = j;
				}
			}
		}
		System.out.println(count);
		if(count == 5 && flags[0] < flags[1] && flags[1] < flags[2] && 
		   flags[2] < flags[3] && flags[3] < flags[4]){
				System.out.println("Koi Mil Gaya");
			}else{
			System.out.println("Get Out!!");
		}*/
		Date d = new Date("2014/8/22");
		System.out.println(d);
	}
}