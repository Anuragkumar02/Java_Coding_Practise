package com.me.client;

public class ClientWrappers {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Wrappers object instantiations
		//TODO Study the constructors & autoboxing.
		Integer i = 10;//autoboxing. i.e. for primitive values are put implicitly into Integer object.
		//Above feature is available since Jdk 1.5.
		
		Integer j = new Integer(20);
		Integer k = new Integer("30");
		
		Integer l = Integer.valueOf("40");
		Integer m = Integer.valueOf(50);
		
		System.out.println("i: " + i);
		System.out.println("j: " + j);
		System.out.println("k: " + k);
		System.out.println("l: " + l);
		System.out.println("m: " + m);
		Boolean status = true;//Autoboxing.
		//Integer i = 10;
		//Boolean status = true;//Autoboxing.
		Boolean isTrue = new Boolean("Hi!");//Anything other than "true", is false
		int n = i;//Unboxing. i.e. Putting the boxed value to primitive.
		
		System.out.println("Printing primitive & wrapper:");
		System.out.println("i = " + i);
		System.out.println("Boolean status: " + status);
		System.out.println("Boolean isTrue: " + isTrue);
		System.out.println(n);
		
		//From Wrappers to String. Invoke the toString() method for respective wrapper.
		
		System.out.println("Printing after conversion from wrapper to string:");
		String strStatus = status.toString();
		System.out.println(strStatus);
		
		//From Wrappers to Primitive. Call XValue() function where X is the 
		//data type to which value is to be converted.
		
		boolean s = status.booleanValue();
		int x = m.intValue();
		short height = m.shortValue();
		
		System.out.println("From Wrapper to Primitive:");
		System.out.println(s);
		System.out.println(x);
		System.out.println(height);
		
		//Converting Primitive values to String.
		char ch = 'a';
		byte ofPizza = 100;
		short distance = 12000;
		int shint = 65000;
		float boat = 34.56f;
		double trouble = 90.89;
		
		String strCh = Character.toString(ch);
		String strOfPizza = Byte.toString(ofPizza);
		String strDistance = Short.toString(distance);
		String strShint = Integer.toString(shint);
		String strBoat = Float.toString(boat);
		String strTrouble = Double.toString(trouble);
		
		System.out.println("After coverting Primitive values to String:");
		
		System.out.println(strCh);
		System.out.println(strOfPizza);
		System.out.println(strDistance);
		System.out.println(strShint);
		System.out.println(strBoat);
		System.out.println(strTrouble);
		
		float pi = 3.14f;
		double Pi = 3.14;
		
		if(pi == Pi){
			System.out.println("Same");
		}else{
			System.out.println("Not Same");
		}
		System.out.printf("float pi:%.8f\n",pi);
		System.out.printf("double pi:%.16f\n",Pi);
		
		/*Float f = 3.14f;
		Double d = 3.14;
		
		if(f == d)
			System.out.println("Yes");*/
	}
}