package com.me.client;

public class MyInteger {
	private int value;

	public MyInteger() {
		super();
	}

	public MyInteger(int value) {
		super();
		this.value = value;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "MyInteger [value=" + value + "]";
	}
	
	
}