package com.me.client;

public class MyWrapperDemo {

	public static void main(String[] args) {
		MyInteger number ;
		number = new MyInteger(10);
		System.out.println(number);
		
		int n = number;
	}
}