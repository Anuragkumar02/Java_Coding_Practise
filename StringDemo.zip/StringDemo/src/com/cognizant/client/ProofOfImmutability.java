package com.cognizant.client;

public class ProofOfImmutability {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = new String("abc");
		String str1 = str;
		
		if(str == str1){//References & not the contents, are compared.
			System.out.println("str and str1 are refering to same object.");
		}else{
			System.out.println("str and str1 are refering to different objects.");
		}
		
		str1 += " def";
		//A new object is created with " def" joined. If it is done in the same
		//object then str & str1 should be referring same object.
		if(str == str1){
			System.out.println("This time str and str1 are refering to same object.");
		}else{
			System.out.println("This time str and str1 are refering to different objects.");
		}
		System.out.println("str: " + str);
		System.out.println("str1: " + str1);
	}
}