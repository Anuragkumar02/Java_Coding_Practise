package com.cognizant.client;

public class StringConstantPool {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "What's App?";
		String str1 = "What's App?";
		
		if(str == str1){
			System.out.println("Both are same.");
		}else{
			System.out.println("Both are not same.");
		}
		
		String str2 = "What's "+"App?";
		
		if(str1 == str2){
			System.out.println("Again both are same.");
		}else{
			System.out.println("Again both are not same.");
		}
		
		String str3 = "What's "+new String("App?");
		
		if(str2 == str3){
			System.out.println("Third time both are same.");
		}else{
			System.out.println("Third time both are not same.");
		}
		
		str3 = str3.intern();
		
		if(str2 == str3){
			System.out.println("Fourth time both are same.");
		}else{
			System.out.println("Fourth time both are not same.");
		}
	}
}