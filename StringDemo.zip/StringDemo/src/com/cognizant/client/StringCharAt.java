package com.cognizant.client;

public class StringCharAt {

	public static void main(String[] args) {
		String text = new String("Hello There");
		
		System.out.println(text.charAt(4));
	}
}