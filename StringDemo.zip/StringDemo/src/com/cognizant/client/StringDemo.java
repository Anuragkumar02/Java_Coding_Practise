package com.cognizant.client;

public class StringDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Ways to Instantiate a String
		String str = new String("abc");//Object is on heap.
		String str1 = new String();//A String with "" as initial state.
		
		char str2[] = {'h','i','g','h'};
		String str3 = new String(str2);
		
		byte byteOfPi[] ={65,65,65};
		String str4 = new String(byteOfPi);
		//There many such constructors. Google to find'em out!!
		
		System.out.println(str);
		System.out.println(str1);
		System.out.println(str3);
		System.out.println(str4);
		
		System.out.println("Is str1 empty? " + str1.isEmpty());
	}
}