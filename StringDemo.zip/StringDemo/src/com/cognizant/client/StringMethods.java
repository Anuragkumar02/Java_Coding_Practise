package com.cognizant.client;

public class StringMethods {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = new String("You can fool some people all the time.\n"+
								"You can fool all the people some time.\n"+
								"But you cannot fool all the people all time.");
		
		int index = str.indexOf('f');
		System.out.println("First fool is found at position " + index);
		
		index = str.indexOf('f', index+1);
		System.out.println("Second fool is found at position " + index);
		
		index = str.indexOf("fool");
		System.out.println("First fool is found at position " + index);
		
		index = str.indexOf("fool", index+1);
		System.out.println("Second fool is found at position " + index);
		
		int lastIndex = str.lastIndexOf('f');
		System.out.println("Last fool is found at position " + lastIndex);
		
		lastIndex = str.lastIndexOf('f', lastIndex-1);
		System.out.println("Second last fool is found at position " + lastIndex);
		
		System.out.println("SubString: "+str.substring(18));
		System.out.println("SubString: "+str.substring(18,25));
		
		String[] fullName = new String("Narendra  Damodar  Modi").split(" ");

		for(String n : fullName){
			System.out.println(n);
		}
		
		System.out.println("Accessing individual characters of string: ");
		
		for (int i = 0; i < str.length(); i++) {
			System.out.print(str.charAt(i));
		}
		
		String toBeTrimmed = new String("   abc   ");
		System.out.println("\nBefore trimming: " + toBeTrimmed + "...");
		System.out.println("After trimming: " + toBeTrimmed.trim()+"...");
		
		String funnyString = "Java Jives";
		System.out.println(funnyString);
		funnyString = funnyString.replace('J', 'W');
		System.out.println(funnyString);
		
		funnyString = funnyString.concat(" is a funny String");
		System.out.println(funnyString);
		
		String company = new String("cogniza");
		String anotherCompany = new String("cognizant!");
		
		int result = company.compareTo(anotherCompany);
		System.out.println(result);
		
		company = "cognizant";
		anotherCompany = "Cognizant";
		
		boolean areTheySame = company.equals(anotherCompany);
		System.out.println("Are both companies same? " + areTheySame);
		
		areTheySame = company.equalsIgnoreCase(anotherCompany);
		System.out.println("Are both companies same? " + areTheySame);
	}
}