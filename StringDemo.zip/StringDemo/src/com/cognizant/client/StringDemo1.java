package com.cognizant.client;

public class StringDemo1 {

	public static void main(String[] args) {
		String str = String.valueOf(1000);
		
		System.out.println(str);
	}
}