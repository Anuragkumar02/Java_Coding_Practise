package com.cognizant.client;

public class StringBufferDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Initial capacity is 16 characters. When 17th char. is inserted.
		// It gets stretched to 34 i.e. twice the capacity of new position.
		StringBuffer sbf = new StringBuffer("India");
		System.out.println(sbf);
		
		sbf.append(" has very bright future.");
		System.out.println(sbf);
		
		sbf.delete(10, 15);
		System.out.println(sbf);
		
		sbf.replace(17,23, "past");
		System.out.println(sbf);
		
		sbf.insert(9," very");
		System.out.println(sbf);
		
		sbf.setCharAt(sbf.length()-1, '?');
		System.out.println(sbf);
		
		String substring = sbf.substring(0, 5);
		System.out.println(substring);
		
		sbf.setLength(sbf.length()-1);
		System.out.println(sbf);
		
		sbf.reverse();
		System.out.println(sbf);
	}
}