package com.cognizant.client;

import java.util.StringTokenizer;

public class StringTokenizers {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String str = "This   is   String, split   by StringTokenizer, separated by commas";
		StringTokenizer sToken = new StringTokenizer(str, ",");
		
		for(;sToken.hasMoreTokens();){
			System.out.println(sToken.nextToken());
		}
		
		sToken = new StringTokenizer(str);
		
		while(sToken.hasMoreTokens()){
			System.out.println(sToken.nextToken());
		}
	}
}